@echo off
cd /d "%~dp0"
echo Waiting for Minecraft (start the game now, up to 5 minutes)...
SlinkyInjector.exe --wait 300
echo.
pause
