#Requires -RunAsAdministrator
# Blocks outbound traffic for this loader folder (and optionally the game's java.exe).
#
#   .\block-network.ps1
#   .\block-network.ps1 -JavaExe "D:\...\BadlionOffline\java17\bin\java.exe"
#   .\block-network.ps1 -Remove

param(
    [string[]]$Program = @(),
    [string]$JavaExe = '',
    [switch]$Remove
)

$prefix = 'Slinky-Block-Out-'

if ($Remove) {
    Get-NetFirewallRule -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like "$prefix*" } |
        ForEach-Object { Remove-NetFirewallRule -Name $_.Name; Write-Host "removed: $($_.DisplayName)" }
    return
}

$targets = @()
if ($Program.Count -gt 0) { $targets += $Program } else { $targets += (Join-Path $PSScriptRoot 'SlinkyInjector.exe') }
if ($JavaExe -ne '') { $targets += $JavaExe }

foreach ($path in $targets) {
    if (-not (Test-Path -LiteralPath $path)) { Write-Warning "skip (not found): $path"; continue }
    $full = (Resolve-Path -LiteralPath $path).Path
    $name = $prefix + [IO.Path]::GetFileNameWithoutExtension($full)
    Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    New-NetFirewallRule -DisplayName $name -Direction Outbound -Program $full -Action Block -Profile Any -Enabled True | Out-Null
    Write-Host "blocked outbound: $full"
}

Get-NetFirewallRule -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -like "$prefix*" } |
    Select-Object DisplayName, Enabled, Direction, Action | Format-Table -AutoSize
